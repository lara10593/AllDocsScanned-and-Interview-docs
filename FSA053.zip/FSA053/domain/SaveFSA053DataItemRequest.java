package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;import com.fasterxml.jackson.annotation.JsonProperty;import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import uk.org.fca.gabriel.common.domain.CommonDataItem;import uk.org.fca.gabriel.common.domain.FirmDataItem;import uk.org.fca.gabriel.common.domain.SaveDataItemRequest;import java.util.Objects;/** * SaveFSA053DataItemRequest */

public class SaveFSA053DataItemRequest extends SaveDataItemRequest {  @JsonProperty("DataItem")  private FSA053DataItem fsA053DataItem = null;   
 public SaveFSA053DataItemRequest() {        // default constructor    }    
 public SaveFSA053DataItemRequest(FSA053DataItem commonDataItem            , FirmDataItem firmDataItem) 
 {       
 super(firmDataItem.getFirmReferenceNumber(),firmDataItem.getFirmDataItemId(),firmDataItem.getPeriodStartDate(),firmDataItem.getPeriodEndDate()              
 ,firmDataItem.getSubmissionDueDate(),firmDataItem.getHandbookReference());        this.fsA053DataItem = commonDataItem;    }   

 @Override  public CommonDataItem getDataItem() {    
 
 return this.fsA053DataItem;  } 


 public void setDataItem(CommonDataItem fsaDataItem) {  
 this.fsA053DataItem = (FSA053DataItem) fsaDataItem;  }   

 public FSA053DataItem getFsA053DataItem() {        
 
 return this.fsA053DataItem;    }    
 
 public void setFsA053DataItem(FSA053DataItem fsA053DataItem) {    

 this.fsA053DataItem = fsA053DataItem;    }    
 
 @Override    public boolean equals(Object o) {    
 if (this == o) return true;        if (o == null || getClass() != o.getClass()) return false;      
 if (!super.equals(o)) return false;        
 SaveFSA053DataItemRequest that = (SaveFSA053DataItemRequest) o;       
 return Objects.equals(fsA053DataItem, that.fsA053DataItem);    }   

 @Override    public int hashCode() {        
return Objects.hash(super.hashCode(), fsA053DataItem);    }  
 
 @Override    public String toString() {        return "SaveFSA053DataItemRequest{" +         
 "fsA053DataItem=" + fsA053DataItem +                '}';    }}