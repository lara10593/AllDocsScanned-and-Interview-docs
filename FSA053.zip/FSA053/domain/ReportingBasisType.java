package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;import com.fasterxml.jackson.annotation.JsonCreator;import com.fasterxml.jackson.annotation.JsonValue;/** * Gets or Sets ReportingBasisType */

public enum ReportingBasisType {  

UNCONSOLIDATED("unconsolidated"),  SOLO_CONSOLIDATED("solo-consolidated"),  UK_CONSOLIDATION_GROUP("UK consolidation group"),  BANKING_CONGLOMERATE("banking conglomerate"),  
INVESTMENT_CONGLOMERATE("investment conglomerate"),  UK_INTEGRATED_GROUP("UK integrated group"),  DLG_BY_DEFAULT("DLG by default"),  UK_DLG_BY_MODIFICATION("UK DLG by modification"),  
NON_UK_DLG_BY_MODIFICATION("Non-UK DLG by modification");  

private String value;  ReportingBasisType(String value) {    

this.value = value;  }  @Override  @JsonValue  public String toString() {   
 return String.valueOf(value);  }  @JsonCreator  
public static ReportingBasisType fromValue(String text) {    for (ReportingBasisType b : ReportingBasisType.values()) {     

 if (String.valueOf(b.value).equals(text)) {        return b;      }    }    return null;  
 }}