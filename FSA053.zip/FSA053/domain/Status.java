package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;import java.util.Objects;/** * Status */


public class Status {  @JsonProperty("name")  

private String name = null;  @JsonProperty("description") 
 private String description = null;    public Status() {        
 
 // default constructor    }    
 
 public String getName() {        return this.name;    }  

 public String getDescription() {        return this.description;    }   

 public void setName(String name) {        this.name = name;    }   
 public void setDescription(String description) {        this.description = description;    }    
 
 @Override    public boolean equals(Object o) {        if (this == o) return true;        if (o == null || getClass() != o.getClass()) return false;     
 Status status = (Status) o;        return Objects.equals(name, status.name) &&             
 Objects.equals(description, status.description);    }    
 
 @Override    public int hashCode() {        return Objects.hash(name, description);  
  }   

  @Override    public String toString() {     
  return "Status{" +                "name='" + name + '\'' +     
  ", description='" + description + '\'' +                '}';    }}