package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;import com.fasterxml.jackson.annotation.JsonCreator;import com.fasterxml.jackson.annotation.JsonValue;/** * Gets or Sets LimitedCurrencyType */


public enum LimitedCurrencyType {  

CAD("CAD"),  CHF("CHF"),  EUR("EUR"),  GBP("GBP"),  JPY("JPY"),  SEK("SEK"),  USD("USD"); 

 private String value;  LimitedCurrencyType(String value) {    
 
 this.value = value;  } 

 @Override  @JsonValue  public String toString() {   

 return String.valueOf(value);  } 

 @JsonCreator  
public static LimitedCurrencyType 
fromValue(String text) {   
 for (LimitedCurrencyType b : LimitedCurrencyType.values()) {  
 if (String.valueOf(b.value).equals(text)) {        
 return b;      }    }    return null; 
 }}