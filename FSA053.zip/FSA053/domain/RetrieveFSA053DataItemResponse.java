package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import uk.org.fca.gabriel.common.domain.CommonDataItem;
import uk.org.fca.gabriel.common.domain.RetrieveDataItemResponse;
import java.util.Objects;
/** * RetrieveFSA053DataItemResponse */public class RetrieveFSA053DataItemResponse extends RetrieveDataItemResponse {
    @JsonProperty("firmReferenceNumber")
    private Integer firmReferenceNumber = null;
    @JsonProperty("firmDataItemId")
    private Integer firmDataItemId = null;
    @JsonProperty("DataItem")
    private FSA053DataItem fsA053DataItem = null;
    public RetrieveFSA053DataItemResponse()
 {
        // default constructor    }
  public void setDataItem(CommonDataItem fsaDataItem)
 {
        this.fsA053DataItem = (FSA053DataItem)
 fsaDataItem;
    }
    @Override    public Integer getFirmReferenceNumber()
 {
        return this.firmReferenceNumber;
    }
    @Override    public Integer getFirmDataItemId()
 {
        return this.firmDataItemId;
    }
    public FSA053DataItem getFsA053DataItem()
 {
        return this.fsA053DataItem;
    }
    @Override    public void setFirmReferenceNumber(Integer firmReferenceNumber)
 {
        this.firmReferenceNumber = firmReferenceNumber;
    }
    @Override    public void setFirmDataItemId(Integer firmDataItemId)
 {
        this.firmDataItemId = firmDataItemId;
    }
    public void setFsA053DataItem(FSA053DataItem fsA053DataItem)
 {
        this.fsA053DataItem = fsA053DataItem;
    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        RetrieveFSA053DataItemResponse that = (RetrieveFSA053DataItemResponse)
 o;
        return Objects.equals(firmReferenceNumber, that.firmReferenceNumber)
 &&                Objects.equals(firmDataItemId, that.firmDataItemId)
 &&                Objects.equals(fsA053DataItem, that.fsA053DataItem)
;
    }
    @Override    public int hashCode()
 {
        return Objects.hash(firmReferenceNumber, firmDataItemId, fsA053DataItem)
;
    }
    @Override    public String toString()
 {
        return "RetrieveFSA053DataItemResponse{
" +                "firmReferenceNumber=" + firmReferenceNumber +                ", firmDataItemId=" + firmDataItemId +                ", fsA053DataItem=" + fsA053DataItem +                '}
';
    }
}
