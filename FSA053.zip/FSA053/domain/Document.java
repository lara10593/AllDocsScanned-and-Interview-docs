package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;import java.util.ArrayList;/** * 

Document */

public class Document extends ArrayList<byte[]>  

{    

public Document() {        // default constructor    }    

@Override    public String toString() {        return "Document{}";    
}
}