package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import uk.org.fca.gabriel.common.domain.CommonDataItem;

import uk.org.fca.gabriel.common.domain.FirmProfile;

import uk.org.fca.gabriel.common.domain.SaveDataItemRequest;

import uk.org.fca.gabriel.common.domain.ValidationErrorResponse;

import java.util.*;

/** * FSA053DataItem */public class FSA053DataItem extends CommonDataItem {  @JsonProperty("FSA053-RetailAndCorporateFunding")
  private FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding = null;

  @JsonProperty("firmProfile")
  private FirmProfile firmProfile = null;

    @Override    @JsonIgnore    public String getKsession()
{return "    ksession-rules-FSA053-v1";

}
  public FSA053DataItem()
 {    super()
;

  }
  public FSA053DataItem(FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding, FirmProfile firmProfile)
 {    this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;

    this.firmProfile = firmProfile;

  }
  public FSA053DataItem(List<ValidationErrorResponse> validationErrorResponse, FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding, FirmProfile firmProfile)
 {    super(validationErrorResponse)
;

    this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;

    this.firmProfile = firmProfile;

  }
    public FSA053RetailAndCorporateFunding getFsA053RetailAndCorporateFunding()
 {        return this.fsA053RetailAndCorporateFunding;

    }
    public FirmProfile getFirmProfile()
 {        return this.firmProfile;

    }
    public void setFsA053RetailAndCorporateFunding(FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding)
 {        this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;

    }
    public void setFirmProfile(FirmProfile firmProfile)
 {        this.firmProfile = firmProfile;

    }
    @Override    @JsonIgnore    public boolean isGroupSubmissionApplcable()
{        return true;

    }
    @Override    @JsonIgnore    public void setStructuredFrns(List<Integer> frnList)
{        fsA053RetailAndCorporateFunding.getGroupInfo()
.getOtherGroupFirms()
.setFirmReferenceNumber(frnList)
;

    }
    @Override    public boolean equals(Object o)
 {        if (this == o)
 return true;

        if (o == null || getClass()
 != o.getClass()
)
 return false;

        if (!super.equals(o)
)
 return false;

        FSA053DataItem that = (FSA053DataItem)
 o;

        return Objects.equals(fsA053RetailAndCorporateFunding, that.fsA053RetailAndCorporateFunding)
 &&                Objects.equals(firmProfile, that.firmProfile)
;

    }
    @Override    public int hashCode()
 {        return Objects.hash(super.hashCode()
, fsA053RetailAndCorporateFunding, firmProfile)
;

    }
    @Override    public String toString()
 {        return "FSA053DataItem{" +                "fsA053RetailAndCorporateFunding=" + fsA053RetailAndCorporateFunding +                ", firmProfile=" + firmProfile +                '}
';

    }
    @Override    @JsonIgnore    public List<Integer> listOfFrns()
{        List<Integer> list=new ArrayList<>()
;

        for(Integer frn:fsA053RetailAndCorporateFunding.getGroupInfo()
.getOtherGroupFirms()
.getFirmReferenceNumber()
)
{            if(frn!=null)
{                list.add(frn)
;

            }
        }
        return list;

    }
    @Override    @JsonIgnore    public Map<Integer,String> getElement()
{        OtherGroupFirms otherGroupFirms=fsA053RetailAndCorporateFunding.getGroupInfo()
.getOtherGroupFirms()
;

        Map<Integer,String> map=new HashMap<>()
;

        String parent="FSA053-RetailAndCorporateFunding.GroupInfo.OtherGroupFirms.FirmReferenceNumber.";

        String element="";

        for(int i=0;

i<otherGroupFirms.getFirmReferenceNumber()
.size()
;

i++)
 {            element = parent + i;

            map.put(otherGroupFirms.getFirmReferenceNumber()
.get(i)
,element)
;

        }
        return map;

    }
    @Override    public Object getRequiredSchemaValObject(SaveDataItemRequest request)
 {        return (((FSA053DataItem)
 request.getDataItem()
)
.getFsA053RetailAndCorporateFunding()
)
;

    }
    @Override    public Object getRequiredDroolsValObject(SaveDataItemRequest request)
 {        return request.getDataItem()
;

    }
}
