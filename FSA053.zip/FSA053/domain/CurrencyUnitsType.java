package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;

import com.fasterxml.jackson.annotation.JsonCreator;

import com.fasterxml.jackson.annotation.JsonValue;

/** * Gets or Sets CurrencyUnitsType */

public enum CurrencyUnitsType {  

DECIMAL("decimal"),  
SINGLE("single"),  
THOUSANDS("thousands"),  
MILLIONS("millions");  

private String value; 

 CurrencyUnitsType(String value) {   

 this.value = value;  }  
 
 @Override 

 @JsonValue 

 public String toString() {    
 
 return String.valueOf(value);  
 
 }  
@JsonCreator  
public static CurrencyUnitsType fromValue(String text) {    
for (CurrencyUnitsType b : CurrencyUnitsType.values()) {      
if (String.valueOf(b.value).equals(text)) {        
return b;      }    
}    return null;  
}
}