package uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;
/** * FSCSTypeProtection */public class FSCSTypeProtection {
  @JsonProperty("ProtectedBalance")
  private Long protectedBalance = null;
  @JsonProperty("UnprotectedBalance")
  private Long unprotectedBalance = null;
    public FSCSTypeProtection()
 {
        // default constructor    }
    public Long getProtectedBalance()
 {
        return this.protectedBalance;
    }
    public Long getUnprotectedBalance()
 {
        return this.unprotectedBalance;
    }
    public void setProtectedBalance(Long protectedBalance)
 {
        this.protectedBalance = protectedBalance;
    }
    public void setUnprotectedBalance(Long unprotectedBalance)
 {
        this.unprotectedBalance = unprotectedBalance;
    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        FSCSTypeProtection that = (FSCSTypeProtection)
 o;
        return Objects.equals(protectedBalance, that.protectedBalance)
 &&                Objects.equals(unprotectedBalance, that.unprotectedBalance)
;
    }
    @Override    public int hashCode()
 {
        return Objects.hash(protectedBalance, unprotectedBalance)
;
    }
   
 @Override    public String toString()
 {
        return "FSCSTypeProtection{
" +                "protectedBalance=" + protectedBalance +                ", unprotectedBalance=" + unprotectedBalance +                '}
';
    }
}
