package uk.org.fca.gabriel.sca.fsa.fsa053.v1.service;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import datadog.trace.api.Trace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import uk.org.fca.gabriel.common.constants.Constants;
import uk.org.fca.gabriel.common.domain.DataProcessingInfo;
import uk.org.fca.gabriel.common.service.ApplicationService;
import uk.org.fca.gabriel.common.utility.CommonUtility;
import uk.org.fca.gabriel.common.utility.XmlToDtoConverter;
import uk.org.fca.gabriel.sca.fsa.common.AppCommonUtility;
import uk.org.fca.gabriel.sca.fsa.common.AppConstants;
import uk.org.fca.gabriel.common.domain.ValidateDataItemResponse;
import uk.org.fca.gabriel.common.exceptions.FirmDataItemNotFoundException;
import uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain.Document;
import uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto.FSA053DataItem;
import uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto.RetrieveFSA053DataItemResponse;
import uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto.SaveFSA053DataItemRequest;
import javax.annotation.Resource;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import java.util.Map;
@RestControllerpublic class FSA053ApiController {
   

private static final Logger LOGGER = LoggerFactory.getLogger(FSA053ApiController.class);
    ApplicationService applicationService;
    private String handbook = AppConstants.FSA053;
    private String kModule = "ksession-rules-FSA053-v1";
    private String version = "1";
    @Autowired    
	XmlToDtoConverter xmlToDtoConverter;
    @Autowired    
	public void setApplicationService(ApplicationService applicationService) {
       this.applicationService = applicationService;
    }
    
	
	@Trace   
	@Produces({"application/xml","application/json"}
)    
	@Consumes({"application/xml","application/json"}
)    
	@GetMapping("/FSA/FSA053/v1")    
	public ResponseEntity<RetrieveFSA053DataItemResponse> retrieve(@Valid @RequestParam(value = "firmReferenceNumber", required = true) Integer firmReferenceNumber, @Valid @RequestParam(value = "firmDataItemId", required = true) Integer firmDataItemId, @RequestHeader Map<String, String> headers) 
	{
       
	LOGGER.info("Retrieve FirmDataItem Controller");
        RetrieveFSA053DataItemResponse response = new RetrieveFSA053DataItemResponse();
        if(null==firmDataItemId || null == firmReferenceNumber){
           throw new FirmDataItemNotFoundException();
        }
        response.setFirmReferenceNumber(firmReferenceNumber);
        response.setFirmDataItemId(firmDataItemId);
        response = (RetrieveFSA053DataItemResponse) applicationService.retrieve(response, FSA053DataItem.class, getDataProcessingObj(Constants.ONLINE, null, headers));
        LOGGER.info("Retrieve FirmDataItem Controller successful");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @Trace    @Produces({"application/xml", "application/json"}
)    @Consumes({"application/xml", "application/json"}
)    @PutMapping("/FSA/FSA053/save/v1")    public ResponseEntity<String> saveAsDraft(@Valid @RequestBody SaveFSA053DataItemRequest request, @RequestHeader Map<String, String> headers){
       LOGGER.info("SaveAsDraft FirmDataItem Controller");
        if(null==request || null==request.getFirmDataItemId() || null == request.getFirmReferenceNumber() || null==request.getFsA053DataItem())            throw new FirmDataItemNotFoundException();
        String response = applicationService.saveAsDraft(request, getDataProcessingObj(Constants.ONLINE, null, headers));
        LOGGER.info("SaveAsDraft FirmDataItem Controller successful");
        return new ResponseEntity<>(response,HttpStatus.OK);
    }
    @Trace    @Produces({"application/xml", "application/json"}
)    @Consumes({"application/xml", "application/json"}
)    @PutMapping("/FSA/FSA053/validate/v1")    public ResponseEntity<ValidateDataItemResponse> validateAndSave(@Valid @RequestBody SaveFSA053DataItemRequest request, @RequestHeader Map<String, String> headers) {
       LOGGER.info("Inside FSA053ApiController > validateFSA053");
        ValidateDataItemResponse response = null;
        if(null==request || null==request.getFirmDataItemId() || null == request.getFirmReferenceNumber() || null==request.getFsA053DataItem())            throw new FirmDataItemNotFoundException();
        response = applicationService.saveAndValidate(request, getDataProcessingObj(Constants.ONLINE, null, headers));
        LOGGER.info("Inside FSA053ApiController > validateFSA053 : Before return");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @Trace    @Produces({"application/xml", "application/json"}
)    @Consumes({"application/xml", "application/json"}
)    @GetMapping("/FSA/FSA053/downloadPdf/v1")    public ResponseEntity<Document> downloadPDF(@Valid @RequestParam(value = "firmReferenceNumber", required = true) Integer firmReferenceNumber, @Valid @RequestParam(value = "firmDataItemId", required = true) Integer firmDataItemId, @RequestHeader Map<String, String> headers) {
       return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);
    }
    @Trace    @Consumes({"application/xml"}
)    @PutMapping("/FSA/FSA053/xmluploadschemavalidation/v1")    public ResponseEntity<ValidateDataItemResponse> validateSchema(@Valid @RequestBody String request, @RequestHeader Map<String, String> headers) throws Exception{
       LOGGER.info("Inside ApiController > validateSchema");
        //not needed        SaveFSA053DataItemRequest saveFSA053DataItemRequest = (SaveFSA053DataItemRequest)xmlToDtoConverter.covertToDTO(request, SaveFSA053DataItemRequest.class);
        LOGGER.info("converted fsa053 dto object=" + saveFSA053DataItemRequest.toString());
        ValidateDataItemResponse response = applicationService.validateSchema(saveFSA053DataItemRequest, getDataProcessingObj(Constants.XML_UPLOAD, Constants.SCHEMA, headers));
        LOGGER.info("Inside FSA053ApiController > SchemavalidateFSA : Before return");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @Trace    @Produces({"application/xml", "application/json"}
)    @Consumes({"application/xml", "application/json"}
)    @PutMapping("/FSA/FSA053/xmluploadrulevalidation/v1")    public ResponseEntity<ValidateDataItemResponse> validateDrools(@Valid @RequestBody String request, @RequestHeader Map<String, String> headers) {
       LOGGER.info("Inside FSA053ApiController > validateDroolsFSA053");
        SaveFSA053DataItemRequest saveFSA053DataItemRequest = new SaveFSA053DataItemRequest();
        try {
           String rootElementName = saveFSA053DataItemRequest.getClass().getSimpleName();
            LOGGER.info("fsa053 dto rootElementName="+rootElementName);
            request = "<" + rootElementName + ">" + request + "</" + rootElementName + ">";
            XmlMapper mapper = CommonUtility.getXmlMapper();
            saveFSA053DataItemRequest = mapper.readValue(request, SaveFSA053DataItemRequest.class);
            LOGGER.info("saveFSA053DataItemRequest ="+saveFSA053DataItemRequest.toString());
        }
 catch (Exception e) {
           LOGGER.error(e.getMessage());
        }
        ValidateDataItemResponse response = applicationService.validateDrools(saveFSA053DataItemRequest,getDataProcessingObj(Constants.XML_UPLOAD, Constants.BUSINESS, headers));
        LOGGER.info("Inside FSA053ApiController > validateDroolsFSA053 : Before return");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    @Trace    @GetMapping(value = "/FSA/FSA053/downloadXml/v1")    @Consumes({"application/xml", "application/json"}
)    @Produces("application/xml")    public ResponseEntity<Resource> downloadXmlFSA053(            @RequestParam("firmReferenceNumber") Integer firmReferenceNumber,            @RequestParam("firmDataItemId") Integer firmDataItemId,            @RequestHeader Map<String, String> headers) throws Exception {
       InputStreamResource inResource = applicationService.downloadDataItemXML( firmDataItemId, firmReferenceNumber,                getDataProcessingObj(Constants.ONLINE,null,headers));
        return new ResponseEntity(inResource, null, HttpStatus.OK);
    }
    private DataProcessingInfo getDataProcessingObj(String mode, String validationType, Map<String,String> headers){
       DataProcessingInfo d = CommonUtility.getDataProcessingInfo(handbook, version, kModule, headers);
        d.setMode(mode);
        // d.setVersion(version);
        //d.setHandbookReference(handbook);
        //d.setkSessionName(kModule);
        d.setValidationType(validationType);
        return d;
    }
}
