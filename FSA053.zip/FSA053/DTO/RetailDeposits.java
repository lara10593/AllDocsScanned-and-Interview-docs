package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;

/** * RetailDeposits */

public class RetailDeposits {
  @JsonProperty("Current")
  private TypeABStructure current = null;
  @JsonProperty("TaxAdvantaged")
  private TypeABStructure taxAdvantaged = null;
  @JsonProperty("OnDemand")
  private TypeABStructure onDemand = null;
  @JsonProperty("FixedTerm")
  private TypeABStructure fixedTerm = null;
  @JsonProperty("FixedNotice")
  private TypeABStructure fixedNotice = null;
    public RetailDeposits()
 {
        // default constructor    }
    public TypeABStructure getCurrent()
 {
        return this.current;
    }
    public TypeABStructure getTaxAdvantaged()
 {
        return this.taxAdvantaged;
    }
    public TypeABStructure getOnDemand()
 {
        return this.onDemand;
    }
    public TypeABStructure getFixedTerm()
 {
        return this.fixedTerm;
    }
    public TypeABStructure getFixedNotice()
 {
        return this.fixedNotice;
    }
    public void setCurrent(TypeABStructure current)
 {
        this.current = current;
    }
    public void setTaxAdvantaged(TypeABStructure taxAdvantaged)
 {
        this.taxAdvantaged = taxAdvantaged;
    }
    public void setOnDemand(TypeABStructure onDemand)
 {
        this.onDemand = onDemand;
    }
    public void setFixedTerm(TypeABStructure fixedTerm)
 {
        this.fixedTerm = fixedTerm;
    }
    public void setFixedNotice(TypeABStructure fixedNotice)
 {
        this.fixedNotice = fixedNotice;
    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        RetailDeposits that = (RetailDeposits)
 o;
        return Objects.equals(current, that.current)
 &&                Objects.equals(taxAdvantaged, that.taxAdvantaged)
 &&                Objects.equals(onDemand, that.onDemand)
 &&                Objects.equals(fixedTerm, that.fixedTerm)
 &&                Objects.equals(fixedNotice, that.fixedNotice)
;
    }
    @Override    public int hashCode()
 {
        return Objects.hash(current, taxAdvantaged, onDemand, fixedTerm, fixedNotice)
;
    }
    @Override    public String toString()
 {
        return "RetailDeposits{
" +                "current=" + current +                ", taxAdvantaged=" + taxAdvantaged +                ", onDemand=" + onDemand +                ", fixedTerm=" + fixedTerm +                ", fixedNotice=" + fixedNotice +                '}
';
    }
}
