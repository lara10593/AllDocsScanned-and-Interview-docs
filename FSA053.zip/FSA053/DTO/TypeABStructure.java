package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;/** * TypeABStructure */public class TypeABStructure 
{  @JsonProperty("TypeABalance")  private String typeABalance = null;  
@JsonProperty("TypeBBalance")  private String typeBBalance = null;   
 public TypeABStructure() {        // default constructor    }    
 public String getTypeABalance() {        return this.typeABalance;   
 }    public String getTypeBBalance() {        
 return this.typeBBalance;    }   
 public void setTypeABalance(String typeABalance) {    
 this.typeABalance = typeABalance;    }    
 public void setTypeBBalance(String typeBBalance) {    
 this.typeBBalance = typeBBalance;    }    
 @Override    public boolean equals(Object o) {      
 if (this == o) return true;      
 if (o == null || getClass() != o.getClass()) return false;  
 TypeABStructure that = (TypeABStructure) o;  
 return Objects.equals(typeABalance, that.typeABalance) &&  
 Objects.equals(typeBBalance, that.typeBBalance);    } 
 @Override    public int hashCode() {       
 return Objects.hash(typeABalance, typeBBalance);    
}    @Override    public String toString() {       
 return "TypeABStructure{" +               
 "typeABalance=" + typeABalance +         
 ", typeBBalance=" + typeBBalance +                '}';    }}