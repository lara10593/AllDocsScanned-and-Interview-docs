package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;
/** * CorporateAccounts */public class CorporateAccounts {
  @JsonProperty("Current")

  private TypeBStructure current = null;
  @JsonProperty("TaxAdvantaged")
  private TypeBStructure taxAdvantaged = null;
  @JsonProperty("OnDemand")
  private TypeBStructure onDemand = null;
  @JsonProperty("FixedTerm")
  private TypeBStructure fixedTerm = null;
  @JsonProperty("FixedNotice")
  private TypeBStructure fixedNotice = null;
    public CorporateAccounts()
 {
        // default constructor    }
    public TypeBStructure getCurrent()
 {
        return this.current;
    }
    public TypeBStructure getTaxAdvantaged()
 {
        return this.taxAdvantaged;
    }
    public TypeBStructure getOnDemand()
 {
        return this.onDemand;
    }
    public TypeBStructure getFixedTerm()
 {
        return this.fixedTerm;
    }
    public TypeBStructure getFixedNotice()
 {
        return this.fixedNotice;
    }
    public void setCurrent(TypeBStructure current)
 {
        this.current = current;
    }
    public void setTaxAdvantaged(TypeBStructure taxAdvantaged)
 {
        this.taxAdvantaged = taxAdvantaged;
    }
    public void setOnDemand(TypeBStructure onDemand)
 {
        this.onDemand = onDemand;
    }
    public void setFixedTerm(TypeBStructure fixedTerm)
 {
        this.fixedTerm = fixedTerm;
    }
    public void setFixedNotice(TypeBStructure fixedNotice)
 {
        this.fixedNotice = fixedNotice;
    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        CorporateAccounts that = (CorporateAccounts) o;
        return Objects.equals(current, that.current)
 &&                Objects.equals(taxAdvantaged, that.taxAdvantaged)
 &&                Objects.equals(onDemand, that.onDemand)
 &&                Objects.equals(fixedTerm, that.fixedTerm)
 &&                Objects.equals(fixedNotice, that.fixedNotice);
    }
    @Override    public int hashCode()
 {
        return Objects.hash(current, taxAdvantaged, onDemand, fixedTerm, fixedNotice)
;
    }
    @Override    public String toString()
 {
        return "CorporateAccounts{
" +                "current=" + current +                ", taxAdvantaged=" + taxAdvantaged +                ", onDemand=" + onDemand +                ", fixedTerm=" + fixedTerm +                ", fixedNotice=" + fixedNotice +                '}
';
    }
}
