package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;

/** * FSCSTypeProtection */

public class FSCSTypeProtection 
{  

@JsonProperty("ProtectedBalance")  
private String protectedBalance = null;  
@JsonProperty("UnprotectedBalance")  
private String unprotectedBalance = null;    

public FSCSTypeProtection() {        
// default constructor    
}    

public String getProtectedBalance() {        
return this.protectedBalance;    
}   

 public String getUnprotectedBalance() {        
 return this.unprotectedBalance;    
 }    
 
 public void setProtectedBalance(String protectedBalance) {        
 this.protectedBalance = protectedBalance;    
 }    
 
 public void setUnprotectedBalance(String unprotectedBalance) {        
 this.unprotectedBalance = unprotectedBalance;    
 }    
 
 @Override    
 public boolean equals(Object o) {        
 if (this == o) return true;        
 if (o == null || getClass() != o.getClass()) return false;        
 FSCSTypeProtection that = (FSCSTypeProtection) o;        
 return Objects.equals(protectedBalance, that.protectedBalance) && 
 Objects.equals(unprotectedBalance, that.unprotectedBalance);   
 }    
 
 @Override    
 public int hashCode() {        
 return Objects.hash(protectedBalance, unprotectedBalance);    
 }    
 
 @Override    
 public String toString() {        
 return "FSCSTypeProtection{" +                "protectedBalance=" + protectedBalance +                ", unprotectedBalance=" + unprotectedBalance +                '}';    
 
 }
 
 }