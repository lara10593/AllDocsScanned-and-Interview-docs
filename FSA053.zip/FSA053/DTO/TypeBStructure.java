package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.Objects;

/**
 * TypeBStructure
 */
public class TypeBStructure {
    @JsonProperty("TypeBBalance")
    private String typeBBalance = null;

    public TypeBStructure() {
        // default constructor
        }

        public String getTypeBBalance() {
        return this.typeBBalance;
    }

    public void setTypeBBalance(String typeBBalance) {

        this.typeBBalance = typeBBalance;    }

        @Override

        public boolean equals(Object o) {

        if (this == o) return true;

        if (o == null || getClass() != o.getClass()) return false;

        TypeBStructure that = (TypeBStructure) o;

        return Objects.equals(typeBBalance, that.typeBBalance);

    }

    @Override

    public int hashCode() {

        return Objects.hash(typeBBalance);

    }

    @Override

    public String toString() {

        return "TypeBStructure{" +

                "typeBBalance=" + typeBBalance +                '}';

    }}