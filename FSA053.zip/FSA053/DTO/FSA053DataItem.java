package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uk.org.fca.gabriel.common.domain.CommonDataItem;
import uk.org.fca.gabriel.common.domain.FirmProfile;
import uk.org.fca.gabriel.common.domain.SaveDataItemRequest;
import uk.org.fca.gabriel.common.domain.ValidationErrorResponse;
import java.io.IOException;
import java.util.*;
/** * FSA053DataItem */

public class FSA053DataItem extends CommonDataItem {
    public static final Logger LOGGER = LoggerFactory.getLogger(FSA053DataItem.class)
;
  @JsonProperty("FSA053-RetailAndCorporateFunding")
  private FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding = null;
  @JsonProperty("firmProfile")
  private FirmProfile firmProfile = null;
    @Override    @JsonIgnore    public String getKsession()
{
return "ksession-rules-FSA053-v1";
}
  public FSA053DataItem()
 {
    super()
;
  }
  public FSA053DataItem(FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding, FirmProfile firmProfile)
 {
    this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;
    this.firmProfile = firmProfile;
  }
  public FSA053DataItem(List<ValidationErrorResponse> validationErrorResponse, FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding, FirmProfile firmProfile)
 {
    super(validationErrorResponse)
;
    this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;
    this.firmProfile = firmProfile;
  }
    public FSA053RetailAndCorporateFunding getFsA053RetailAndCorporateFunding()
 {
        return this.fsA053RetailAndCorporateFunding;
    }
    public FirmProfile getFirmProfile()
 {
        return this.firmProfile;
    }
    public void setFsA053RetailAndCorporateFunding(FSA053RetailAndCorporateFunding fsA053RetailAndCorporateFunding)
 {
        this.fsA053RetailAndCorporateFunding = fsA053RetailAndCorporateFunding;
    }
    public void setFirmProfile(FirmProfile firmProfile)
 {
        this.firmProfile = firmProfile;
    }
    @Override    @JsonIgnore    public boolean isGroupSubmissionApplcable()
{
        return true;
    }
//    @Override//    @JsonIgnore//    public void setStructuredFrns(List<Integer> frnList)
{
//        fsA053RetailAndCorporateFunding.getGroupInfo()
.getOtherGroupFirms()
.setFirmReferenceNumber(frnList)
;
//    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        if (!super.equals(o)
)
 return false;
        FSA053DataItem that = (FSA053DataItem)
 o;
        return Objects.equals(fsA053RetailAndCorporateFunding, that.fsA053RetailAndCorporateFunding)
 &&                Objects.equals(firmProfile, that.firmProfile)
;
    }
    @Override    public int hashCode()
 {
        return Objects.hash(super.hashCode()
, fsA053RetailAndCorporateFunding, firmProfile)
;
    }
    @Override    public String toString()
 {
        return "FSA053DataItem{
" +                "fsA053RetailAndCorporateFunding=" + fsA053RetailAndCorporateFunding +                ", firmProfile=" + firmProfile +                '}
';
    }
    @Override    public uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain.FSA053DataItem getRequiredDroolsValObject(SaveDataItemRequest request)
 {
        ObjectMapper mapper = new ObjectMapper( )
;
        uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain.FSA053DataItem fsa053DataItem = new uk.org.fca.gabriel.sca.fsa.fsa053.v1.domain.FSA053DataItem( )
;
        try {
            fsa053DataItem   = mapper.readValue ( mapper.writeValueAsString ( request.getDataItem ( )
 )
 , fsa053DataItem  .getClass ( )
 )
;
        }
 catch ( IOException e)
 {
            LOGGER.error("IOError {
}
",e)
;
        }
        return fsa053DataItem  ;
    }
    @Override    public Object getRequiredSchemaValObject(SaveDataItemRequest request)
 {
        return (((FSA053DataItem)
 request.getDataItem()
)
.getFsA053RetailAndCorporateFunding()
)
;
    }
}
