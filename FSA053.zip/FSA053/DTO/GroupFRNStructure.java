package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.Objects;

/** * GroupFRNStructure */

public class GroupFRNStructure 

{  

@JsonProperty("OtherGroupFirms")  

private OtherGroupFirms otherGroupFirms = null;    

public GroupFRNStructure() 

{        

// default constructor    

}    

public OtherGroupFirms getOtherGroupFirms() {       

 return this.otherGroupFirms;    
 
 }    
 
 public void setOtherGroupFirms(OtherGroupFirms otherGroupFirms) {        
 
 this.otherGroupFirms = otherGroupFirms;    
 
 }    
 
 @Override    
 public boolean equals(Object o) {        
 if (this == o) return true;        
 if (o == null || getClass() != o.getClass()) return false;        
 GroupFRNStructure that = (GroupFRNStructure) o;        
 return Objects.equals(otherGroupFirms, that.otherGroupFirms);    
 }   

 @Override   
 public int hashCode() {        
 return Objects.hash(otherGroupFirms);    
 }    
 
 @Override    
 public String toString() {        
 return "GroupFRNStructure{" +                "otherGroupFirms=" + otherGroupFirms +                '}';    
 
 }
 
 }
