package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto
;import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import java.util.List;import java.util.Objects;

/** * OtherGroupFirms */

public class OtherGroupFirms {  

@JsonProperty("FirmReferenceNumber")  
private List<String> firmReferenceNumber = null;   

 public OtherGroupFirms() {        
 // default constructor    
 }    
 
 public List<String> getFirmReferenceNumber() {       
 return this.firmReferenceNumber;    
 }    
 
 public void setFirmReferenceNumber(List<String> firmReferenceNumber) {        
 
 this.firmReferenceNumber = firmReferenceNumber;    
 
 }    
 
 @Override    
 
 public boolean equals(Object o) {        
 
 if (this == o) return true;        
 
 if (o == null || getClass() != o.getClass()) return false;        
 
 OtherGroupFirms that = (OtherGroupFirms) o;      
 return Objects.equals(firmReferenceNumber, that.firmReferenceNumber);    
 
 }    
 
 @Override    
 public int hashCode() {      
  return Objects.hash(firmReferenceNumber);   
  }    
  
  @Override    
  public String toString() {  
  return "OtherGroupFirms{" +         
  "firmReferenceNumber=" + firmReferenceNumber +                '}';   
  }
  }