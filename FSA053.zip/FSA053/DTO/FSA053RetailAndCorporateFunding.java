package uk.org.fca.gabriel.sca.fsa.fsa053.v1.dto;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import uk.org.fca.gabriel.sca.fsa.common.NameSpaceConstants;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import java.util.Objects;
/** * FSA053RetailAndCorporateFunding */
@JsonRootName(value = "FSA053-RetailAndCorporateFunding")
@XmlAccessorType(XmlAccessType.FIELD)
public class FSA053RetailAndCorporateFunding {
    @JsonProperty("@xmlns")
    private String nameSpace;
    @JacksonXmlProperty    @JsonProperty("@reportingBasis")
    private String reportingBasis = null;
    @JsonProperty("@currency")
    @JacksonXmlProperty    private String currency = null;
    @JsonProperty("@units")
    @JacksonXmlProperty    private String units = null;
    @JsonProperty("GroupInfo")
    private GroupFRNStructure groupInfo = null;
    @JsonProperty("RetailDeposits")
    private RetailDeposits retailDeposits = null;
    @JsonProperty("CorporateAccounts")
    private CorporateAccounts corporateAccounts = null;
    @JsonProperty("FSCSTypeProtection")
    private FSCSTypeProtection fsCSTypeProtection = null;
    public FSA053RetailAndCorporateFunding()
 {
        // default constructor    }
    public String getNameSpace()
 {
        return NameSpaceConstants.URN_FSA_GOV_UK_MER_FSA053_V1;
    }
    public void setNameSpace(String nameSpace)
 {
        this.nameSpace = nameSpace;
    }
    public GroupFRNStructure getGroupInfo()
 {
        return this.groupInfo;
    }
    public RetailDeposits getRetailDeposits()
 {
        return this.retailDeposits;
    }
    public CorporateAccounts getCorporateAccounts()
 {
        return this.corporateAccounts;
    }
    public FSCSTypeProtection getFsCSTypeProtection()
 {
        return this.fsCSTypeProtection;
    }
    public void setGroupInfo(GroupFRNStructure groupInfo)
 {
        this.groupInfo = groupInfo;
    }
    public void setRetailDeposits(RetailDeposits retailDeposits)
 {
        this.retailDeposits = retailDeposits;
    }
    public void setCorporateAccounts(CorporateAccounts corporateAccounts)
 {
        this.corporateAccounts = corporateAccounts;
    }
    public void setFsCSTypeProtection(FSCSTypeProtection fsCSTypeProtection)
 {
        this.fsCSTypeProtection = fsCSTypeProtection;
    }
    public String getReportingBasis()
 {
        return reportingBasis;
    }
    public void setReportingBasis(String reportingBasis)
 {
        this.reportingBasis = reportingBasis;
    }
    public String getCurrency()
 {
        return currency;
    }
    public void setCurrency(String currency)
 {
        this.currency = currency;
    }
    public String getUnits()
 {
        return units;
    }
    public void setUnits(String units)
 {
        this.units = units;
    }
    @Override    public boolean equals(Object o)
 {
        if (this == o)
 return true;
        if (o == null || getClass()
 != o.getClass()
)
 return false;
        FSA053RetailAndCorporateFunding that = (FSA053RetailAndCorporateFunding)
 o;
        return Objects.equals(groupInfo, that.groupInfo)
 &&                Objects.equals(retailDeposits, that.retailDeposits)
 &&                Objects.equals(corporateAccounts, that.corporateAccounts)
 &&                Objects.equals(fsCSTypeProtection, that.fsCSTypeProtection)
 &&                reportingBasis == that.reportingBasis &&                currency == that.currency &&                units == that.units;
    }
    @Override    public int hashCode()
 {
        return Objects.hash(groupInfo, retailDeposits, corporateAccounts, fsCSTypeProtection, reportingBasis, currency, units)
;
    }
    @Override    public String toString()
 {
        return "FSA053RetailAndCorporateFunding{
" +                "groupInfo=" + groupInfo +                ", retailDeposits=" + retailDeposits +                ", corporateAccounts=" + corporateAccounts +                ", fsCSTypeProtection=" + fsCSTypeProtection +                ", reportingBasis=" + reportingBasis +                ", currency=" + currency +                ", units=" + units +                '}
';
    }
}
